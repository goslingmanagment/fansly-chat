# ChatMuse Build Instructions

## Requirements
- Node.js >= 20
- pnpm (install: `npm install -g pnpm`)
- OS: any (macOS, Linux, Windows)

## Build Steps
```bash
pnpm install
pnpm build
```

Output goes to `dist/` directory. The built extension files are the contents of `dist/`.

## Build Script
`esbuild.config.mjs` — uses esbuild to bundle TypeScript source into browser-ready JS.
