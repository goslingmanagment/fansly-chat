"use strict";
(() => {
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __esm = (fn, res) => function __init() {
    return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
  };
  var __commonJS = (cb, mod) => function __require() {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  };

  // src/popup/styles.css
  var styles_default;
  var init_styles = __esm({
    "src/popup/styles.css"() {
      styles_default = ":root {\n  --chatmuse-bg: #1b1e2e;\n  --chatmuse-panel: #1f2236;\n  --chatmuse-text: #e8e8f0;\n  --chatmuse-muted: #7a7d95;\n  --chatmuse-accent: #5b8af5;\n  --chatmuse-accent-soft: #8bb0ff;\n  --chatmuse-success: #34d399;\n  --chatmuse-danger: #f87171;\n  --chatmuse-border: rgba(255, 255, 255, 0.05);\n  --chatmuse-border-accent: rgba(91, 138, 245, 0.18);\n  color-scheme: dark;\n}\n\nbody {\n  margin: 0;\n  background: var(--chatmuse-bg);\n  color: var(--chatmuse-text);\n  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', system-ui, sans-serif;\n  font-size: 14px;\n  min-width: 320px;\n  -webkit-font-smoothing: antialiased;\n  -moz-osx-font-smoothing: grayscale;\n}\n\n.chatmuse-button {\n  border: 1px solid var(--chatmuse-border);\n  background: rgba(255, 255, 255, 0.04);\n  color: var(--chatmuse-text);\n  padding: 7px 12px;\n  border-radius: 10px;\n  font-family: inherit;\n  font-size: 13px;\n  font-weight: 600;\n  cursor: pointer;\n  transition: background 150ms ease, border-color 150ms ease;\n}\n\n.chatmuse-button:hover {\n  background: rgba(255, 255, 255, 0.08);\n  border-color: rgba(255, 255, 255, 0.1);\n}\n";
    }
  });

  // src/popup/index.ts
  var require_popup = __commonJS({
    "src/popup/index.ts"() {
      init_styles();
      var rootElement = document.getElementById("chatmuse-popup-root");
      if (!(rootElement instanceof HTMLElement)) {
        throw new Error("Missing popup root");
      }
      var root = rootElement;
      function injectStyles() {
        const style = document.createElement("style");
        style.textContent = styles_default;
        document.head.append(style);
      }
      function createButton(label) {
        const button = document.createElement("button");
        button.type = "button";
        button.className = "chatmuse-button";
        button.textContent = label;
        return button;
      }
      async function render() {
        const status = await browser.runtime.sendMessage({ type: "getPopupStatus" });
        root.replaceChildren();
        root.style.padding = "18px";
        root.style.display = "grid";
        root.style.gap = "14px";
        const title = document.createElement("div");
        title.style.display = "grid";
        title.style.gap = "4px";
        const eyebrow = document.createElement("div");
        eyebrow.textContent = "ChatMuse";
        eyebrow.style.fontSize = "12px";
        eyebrow.style.textTransform = "uppercase";
        eyebrow.style.letterSpacing = "0.08em";
        eyebrow.style.color = "var(--chatmuse-accent-soft)";
        const name = document.createElement("div");
        name.textContent = status.mappedPersonalityName ?? (status.accountId ? "Unmapped account" : "Not connected");
        name.style.fontSize = "22px";
        name.style.fontWeight = "800";
        const sub = document.createElement("div");
        sub.textContent = status.connected ? "Fansly session connected" : "Connection not established";
        sub.style.color = "var(--chatmuse-muted)";
        title.append(eyebrow, name, sub);
        const panel = document.createElement("div");
        panel.style.display = "grid";
        panel.style.gap = "8px";
        panel.style.padding = "14px";
        panel.style.borderRadius = "18px";
        panel.style.border = "1px solid var(--chatmuse-border)";
        panel.style.background = "rgba(255,255,255,0.04)";
        const row1 = document.createElement("div");
        row1.textContent = `Account: ${status.accountId ?? "Not connected"}`;
        const row2 = document.createElement("div");
        row2.textContent = `Conversation: ${status.groupId ?? "No active chat"}`;
        row2.style.color = "var(--chatmuse-muted)";
        panel.append(row1, row2);
        const button = createButton("Open Settings");
        button.addEventListener("click", () => {
          void browser.runtime.openOptionsPage();
        });
        root.append(title, panel, button);
      }
      injectStyles();
      void render();
    }
  });
  require_popup();
})();
//# sourceMappingURL=popup.js.map
