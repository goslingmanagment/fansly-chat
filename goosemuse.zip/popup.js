"use strict";
(() => {
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __esm = (fn, res) => function __init() {
    return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
  };
  var __commonJS = (cb, mod) => function __require() {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  };

  // src/popup/styles.css
  var styles_default;
  var init_styles = __esm({
    "src/popup/styles.css"() {
      styles_default = ":root {\n  --goosemuse-bg: #1b1e2e;\n  --goosemuse-panel: #1f2236;\n  --goosemuse-text: #e8e8f0;\n  --goosemuse-muted: #7a7d95;\n  --goosemuse-accent: #5b8af5;\n  --goosemuse-accent-soft: #8bb0ff;\n  --goosemuse-success: #34d399;\n  --goosemuse-danger: #f87171;\n  --goosemuse-border: rgba(255, 255, 255, 0.05);\n  --goosemuse-border-accent: rgba(91, 138, 245, 0.18);\n  color-scheme: dark;\n}\n\nbody {\n  margin: 0;\n  background: var(--goosemuse-bg);\n  color: var(--goosemuse-text);\n  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', system-ui, sans-serif;\n  font-size: 14px;\n  min-width: 320px;\n  -webkit-font-smoothing: antialiased;\n  -moz-osx-font-smoothing: grayscale;\n}\n\n.goosemuse-button {\n  border: 1px solid var(--goosemuse-border);\n  background: rgba(255, 255, 255, 0.04);\n  color: var(--goosemuse-text);\n  padding: 7px 12px;\n  border-radius: 10px;\n  font-family: inherit;\n  font-size: 13px;\n  font-weight: 600;\n  cursor: pointer;\n  transition: background 150ms ease, border-color 150ms ease;\n}\n\n.goosemuse-button:hover {\n  background: rgba(255, 255, 255, 0.08);\n  border-color: rgba(255, 255, 255, 0.1);\n}\n\n.goosemuse-version-tag {\n  position: absolute;\n  top: 12px;\n  right: 12px;\n  padding: 4px 8px;\n  border: 1px solid rgba(255, 255, 255, 0.06);\n  border-radius: 999px;\n  background: rgba(255, 255, 255, 0.03);\n  color: var(--goosemuse-muted);\n  font-size: 11px;\n  line-height: 1;\n  letter-spacing: 0.04em;\n  pointer-events: none;\n}\n";
    }
  });

  // src/popup/index.ts
  var require_popup = __commonJS({
    "src/popup/index.ts"() {
      init_styles();
      var rootElement = document.getElementById("goosemuse-popup-root");
      var extensionVersion = browser.runtime.getManifest().version;
      if (!(rootElement instanceof HTMLElement)) {
        throw new Error("Missing popup root");
      }
      var root = rootElement;
      function injectStyles() {
        const style = document.createElement("style");
        style.textContent = styles_default;
        document.head.append(style);
      }
      function createButton(label) {
        const button = document.createElement("button");
        button.type = "button";
        button.className = "goosemuse-button";
        button.textContent = label;
        return button;
      }
      function createVersionTag() {
        const tag = document.createElement("div");
        tag.className = "goosemuse-version-tag";
        tag.textContent = `v ${extensionVersion}`;
        return tag;
      }
      async function render() {
        const status = await browser.runtime.sendMessage({ type: "getPopupStatus" });
        root.replaceChildren();
        root.style.padding = "18px";
        root.style.display = "grid";
        root.style.gap = "14px";
        root.style.position = "relative";
        const title = document.createElement("div");
        title.style.display = "grid";
        title.style.gap = "4px";
        const eyebrow = document.createElement("div");
        eyebrow.textContent = "GooseMuse";
        eyebrow.style.fontSize = "12px";
        eyebrow.style.textTransform = "uppercase";
        eyebrow.style.letterSpacing = "0.08em";
        eyebrow.style.color = "var(--goosemuse-accent-soft)";
        const name = document.createElement("div");
        name.textContent = status.mappedPersonalityName ?? (status.accountId ? "Unmapped account" : "Not connected");
        name.style.fontSize = "22px";
        name.style.fontWeight = "800";
        const sub = document.createElement("div");
        sub.textContent = status.connected ? "Fansly session connected" : "Connection not established";
        sub.style.color = "var(--goosemuse-muted)";
        title.append(eyebrow, name, sub);
        const panel = document.createElement("div");
        panel.style.display = "grid";
        panel.style.gap = "8px";
        panel.style.padding = "14px";
        panel.style.borderRadius = "18px";
        panel.style.border = "1px solid var(--goosemuse-border)";
        panel.style.background = "rgba(255,255,255,0.04)";
        const row1 = document.createElement("div");
        row1.textContent = `Account: ${status.accountId ?? "Not connected"}`;
        const row2 = document.createElement("div");
        row2.textContent = `Conversation: ${status.groupId ?? "No active chat"}`;
        row2.style.color = "var(--goosemuse-muted)";
        panel.append(row1, row2);
        const button = createButton("Open Settings");
        button.addEventListener("click", () => {
          void browser.runtime.openOptionsPage();
        });
        root.append(createVersionTag(), title, panel, button);
      }
      injectStyles();
      void render();
    }
  });
  require_popup();
})();
//# sourceMappingURL=popup.js.map
